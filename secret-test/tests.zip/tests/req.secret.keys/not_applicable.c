int main() {
    char *secret = "ABCDNONC0C49XZC0GA8Z";
    return 0;
}