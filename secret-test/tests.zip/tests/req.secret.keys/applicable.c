int main() {
    char *secret = "AKIANONC0C49XZC0GA8Z";
    char *secret1 = "gho_Jz55sxIFfpoO2IBBSPQ6YQVaLdk7pue69YiC";
    return 0;
}